<?php

echo '<div><center>
<p>
<font style="color:white;text-align:center;font-family: Brush Script MT, cursive;font-size:80px;">Online Watch Shopes
</font></p></center>
</div>
<div >
  <img class="mySlides" src="img/slideimg/t1.png"  style="height:400px;width:100%">
  <img class="mySlides" src="img/slideimg/a2.png" style="height:400px;width:100%">
  <img class="mySlides" src="img/slideimg/a3.png" style="height:400px;width:100%">
  <img class="mySlides" src="img/slideimg/a4.png" style="height:400px;width:100%">
  <img class="mySlides" src="img/slideimg/a1.png" style="height:400px;width:100%">
</div>';

?>