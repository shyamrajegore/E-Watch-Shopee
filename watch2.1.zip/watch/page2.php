<?php
$id=$_GET['id'];

echo "<h1>".md5($id)."</h1>";



?>

Hello <br>
Page 2
